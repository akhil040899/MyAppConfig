import React, { useState } from 'react';
import { Target, Plus, Trophy, AlertCircle } from 'lucide-react';
import { CarbonGoal } from '../types';

interface GoalsPanelProps {
  goals: CarbonGoal[];
  onAddGoal: (goal: Omit<CarbonGoal, 'id' | 'current'>) => void;
}

const GoalsPanel: React.FC<GoalsPanelProps> = ({ goals, onAddGoal }) => {
  const [showForm, setShowForm] = useState(false);
  const [newGoalType, setNewGoalType] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');
  const [newGoalTarget, setNewGoalTarget] = useState('');
  const [newGoalDescription, setNewGoalDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newGoalTarget || !newGoalDescription) {
      alert('Please fill in all fields');
      return;
    }

    onAddGoal({
      type: newGoalType,
      target: parseFloat(newGoalTarget),
      description: newGoalDescription
    });

    // Reset form
    setNewGoalTarget('');
    setNewGoalDescription('');
    setShowForm(false);
  };

  const getGoalStatus = (goal: CarbonGoal) => {
    const progress = (goal.current / goal.target) * 100;
    if (progress <= 75) return { status: 'good', color: 'green', icon: Trophy };
    if (progress <= 100) return { status: 'warning', color: 'yellow', icon: AlertCircle };
    return { status: 'over', color: 'red', icon: AlertCircle };
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-blue-500 p-2 rounded-lg">
            <Target className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Carbon Goals</h2>
            <p className="text-gray-600">Set and track your carbon reduction targets</p>
          </div>
        </div>
        
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-5 w-5" />
          <span>Add Goal</span>
        </button>
      </div>

      {/* Add Goal Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Goal</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Goal Type
                </label>
                <select
                  value={newGoalType}
                  onChange={(e) => setNewGoalType(e.target.value as any)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target (kg CO₂)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={newGoalTarget}
                  onChange={(e) => setNewGoalTarget(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter target emissions..."
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <input
                type="text"
                value={newGoalDescription}
                onChange={(e) => setNewGoalDescription(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Describe your goal..."
                required
              />
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Create Goal
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Goals List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((goal) => {
          const { status, color, icon: StatusIcon } = getGoalStatus(goal);
          const progress = Math.min((goal.current / goal.target) * 100, 100);

          return (
            <div key={goal.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900">{goal.description}</h3>
                  <p className="text-sm text-gray-500 capitalize">{goal.type} Goal</p>
                </div>
                <div className={`p-2 rounded-lg bg-${color}-100`}>
                  <StatusIcon className={`h-5 w-5 text-${color}-600`} />
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-600">Progress</span>
                  <span className="text-sm font-medium text-gray-900">
                    {goal.current.toFixed(1)} / {goal.target} kg CO₂
                  </span>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className={`h-3 rounded-full transition-all duration-300 bg-${color}-500`}
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>

                <div className="flex justify-between items-center">
                  <span className={`text-sm font-medium text-${color}-600`}>
                    {progress.toFixed(1)}% of target
                  </span>
                  {status === 'over' && (
                    <span className="text-sm text-red-600 font-medium">
                      {((goal.current / goal.target - 1) * 100).toFixed(1)}% over limit
                    </span>
                  )}
                </div>
              </div>

              {status === 'good' && progress > 0 && (
                <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-800">
                    Great job! You're on track to meet your {goal.type} goal.
                  </p>
                </div>
              )}

              {status === 'warning' && (
                <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    You're getting close to your limit. Consider reducing activities.
                  </p>
                </div>
              )}

              {status === 'over' && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-800">
                    You've exceeded your {goal.type} goal. Time to focus on reduction!
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {goals.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 text-center">
          <Target className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Goals Set</h3>
          <p className="text-gray-500 mb-4">
            Set carbon emission goals to track your progress and stay motivated
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Create Your First Goal
          </button>
        </div>
      )}
    </div>
  );
};

export default GoalsPanel;