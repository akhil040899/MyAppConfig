import React, { useState, useEffect } from 'react';
import { Plus, BarChart3, Target, Leaf, Car, Zap, Home, Plane } from 'lucide-react';
import Dashboard from './components/Dashboard';
import ActivityForm from './components/ActivityForm';
import GoalsPanel from './components/GoalsPanel';
import { Activity, CarbonGoal } from './types';

function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'add-activity' | 'goals'>('dashboard');
  const [activities, setActivities] = useState<Activity[]>([]);
  const [goals, setGoals] = useState<CarbonGoal[]>([]);

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedActivities = localStorage.getItem('ecotrack-activities');
    const savedGoals = localStorage.getItem('ecotrack-goals');
    
    if (savedActivities) {
      setActivities(JSON.parse(savedActivities));
    }
    
    if (savedGoals) {
      setGoals(JSON.parse(savedGoals));
    } else {
      // Set default goal
      const defaultGoal: CarbonGoal = {
        id: Date.now().toString(),
        type: 'monthly',
        target: 500,
        current: 0,
        description: 'Monthly Carbon Footprint Goal'
      };
      setGoals([defaultGoal]);
      localStorage.setItem('ecotrack-goals', JSON.stringify([defaultGoal]));
    }
  }, []);

  // Save activities to localStorage whenever activities change
  useEffect(() => {
    localStorage.setItem('ecotrack-activities', JSON.stringify(activities));
    
    // Update current progress in goals
    const totalEmissions = activities.reduce((sum, activity) => sum + activity.carbonFootprint, 0);
    const updatedGoals = goals.map(goal => ({
      ...goal,
      current: totalEmissions
    }));
    setGoals(updatedGoals);
    localStorage.setItem('ecotrack-goals', JSON.stringify(updatedGoals));
  }, [activities]);

  const addActivity = (activity: Omit<Activity, 'id' | 'date'>) => {
    const newActivity: Activity = {
      ...activity,
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0]
    };
    setActivities(prev => [...prev, newActivity]);
  };

  const addGoal = (goal: Omit<CarbonGoal, 'id' | 'current'>) => {
    const newGoal: CarbonGoal = {
      ...goal,
      id: Date.now().toString(),
      current: activities.reduce((sum, activity) => sum + activity.carbonFootprint, 0)
    };
    setGoals(prev => [...prev, newGoal]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-green-500 p-2 rounded-lg">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">EcoTrack</h1>
                <p className="text-sm text-gray-500">Carbon Footprint Tracker</p>
              </div>
            </div>
            
            <nav className="flex space-x-4">
              <button
                onClick={() => setCurrentView('dashboard')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === 'dashboard'
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <BarChart3 className="h-4 w-4 inline mr-2" />
                Dashboard
              </button>
              <button
                onClick={() => setCurrentView('add-activity')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === 'add-activity'
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Plus className="h-4 w-4 inline mr-2" />
                Add Activity
              </button>
              <button
                onClick={() => setCurrentView('goals')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === 'goals'
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Target className="h-4 w-4 inline mr-2" />
                Goals
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'dashboard' && (
          <Dashboard activities={activities} goals={goals} />
        )}
        
        {currentView === 'add-activity' && (
          <ActivityForm onAddActivity={addActivity} />
        )}
        
        {currentView === 'goals' && (
          <GoalsPanel goals={goals} onAddGoal={addGoal} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-500 text-sm">
              EcoTrack v1.2.0 - Helping you reduce your carbon footprint
            </p>
            <p className="text-gray-400 text-xs mt-2">
              Built with React, TypeScript, and Tailwind CSS
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;