export interface Activity {
  id: string;
  type: 'transportation' | 'energy' | 'food' | 'waste' | 'other';
  description: string;
  amount: number;
  unit: string;
  carbonFootprint: number; // kg CO2
  date: string;
}

export interface CarbonGoal {
  id: string;
  type: 'daily' | 'weekly' | 'monthly' | 'yearly';
  target: number; // kg CO2
  current: number; // kg CO2
  description: string;
}

export const ACTIVITY_TYPES = {
  transportation: {
    label: 'Transportation',
    icon: 'Car',
    color: 'blue',
    factors: {
      'car-petrol': { label: 'Car (Petrol)', factor: 0.21, unit: 'km' },
      'car-diesel': { label: 'Car (Diesel)', factor: 0.17, unit: 'km' },
      'car-electric': { label: 'Car (Electric)', factor: 0.05, unit: 'km' },
      'bus': { label: 'Bus', factor: 0.08, unit: 'km' },
      'train': { label: 'Train', factor: 0.04, unit: 'km' },
      'flight-domestic': { label: 'Flight (Domestic)', factor: 0.25, unit: 'km' },
      'flight-international': { label: 'Flight (International)', factor: 0.30, unit: 'km' }
    }
  },
  energy: {
    label: 'Energy',
    icon: 'Zap',
    color: 'yellow',
    factors: {
      'electricity': { label: 'Electricity', factor: 0.5, unit: 'kWh' },
      'natural-gas': { label: 'Natural Gas', factor: 2.0, unit: 'm³' },
      'heating-oil': { label: 'Heating Oil', factor: 2.7, unit: 'L' }
    }
  },
  food: {
    label: 'Food',
    icon: 'Home',
    color: 'green',
    factors: {
      'beef': { label: 'Beef', factor: 27.0, unit: 'kg' },
      'pork': { label: 'Pork', factor: 12.1, unit: 'kg' },
      'chicken': { label: 'Chicken', factor: 6.9, unit: 'kg' },
      'fish': { label: 'Fish', factor: 6.1, unit: 'kg' },
      'vegetables': { label: 'Vegetables', factor: 2.0, unit: 'kg' },
      'dairy': { label: 'Dairy', factor: 3.2, unit: 'kg' }
    }
  },
  waste: {
    label: 'Waste',
    icon: 'Home',
    color: 'red',
    factors: {
      'general-waste': { label: 'General Waste', factor: 0.5, unit: 'kg' },
      'recycling': { label: 'Recycling', factor: 0.1, unit: 'kg' }
    }
  },
  other: {
    label: 'Other',
    icon: 'Home',
    color: 'gray',
    factors: {
      'custom': { label: 'Custom Activity', factor: 1.0, unit: 'unit' }
    }
  }
} as const;