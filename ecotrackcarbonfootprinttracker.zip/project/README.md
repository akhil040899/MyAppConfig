# EcoTrack - Carbon Footprint Tracker

A comprehensive web application for tracking and managing your carbon footprint. Monitor daily activities, set reduction goals, and visualize your environmental impact with an intuitive, modern interface.

## 🌱 Features

### Core Functionality
- **Activity Tracking**: Log daily activities across multiple categories (Transportation, Energy, Food, Waste, Other)
- **Carbon Calculation**: Automatic CO₂ emission calculations using scientifically-backed emission factors
- **Goal Management**: Set and track carbon reduction goals (daily, weekly, monthly, yearly)
- **Progress Visualization**: Interactive dashboard with charts and progress indicators
- **Data Persistence**: Local storage ensures your data is saved between sessions

### Activity Categories
- **Transportation**: Car (Petrol/Diesel/Electric), Bus, Train, Flights
- **Energy**: Electricity, Natural Gas, Heating Oil
- **Food**: Beef, Pork, Chicken, Fish, Vegetables, Dairy
- **Waste**: General Waste, Recycling
- **Custom**: Add your own activities with custom emission factors

### Dashboard Analytics
- Total emissions summary
- Monthly progress tracking
- Emissions breakdown by category
- Goal progress indicators
- Recent activity history

## 🚀 Getting Started

### Prerequisites
- Node.js 18 or higher
- npm or yarn package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/team/ecotrack-carbon-tracker.git
   cd ecotrack-carbon-tracker
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser** and navigate to `http://localhost:5173`

### Building for Production

```bash
# Build the application
npm run build

# Preview the production build
npm run preview
```

## 🛠️ Technology Stack

- **Frontend Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Testing**: Jest + React Testing Library
- **Linting**: ESLint + TypeScript ESLint
- **Version Control**: Git with GitHub

## 📊 Configuration Management

This project follows comprehensive configuration management practices:

### Version Control Strategy
- **Main Branch**: `master` - Production-ready code
- **Development Branch**: `develop` - Integration branch
- **Feature Branches**: `feature/*` - Individual feature development
- **Release Branches**: `release/*` - Release preparation
- **Hotfix Branches**: `hotfix/*` - Critical production fixes

### Development Workflow
1. Create feature branch from `develop`
2. Implement feature with tests
3. Submit pull request with code review
4. Merge to `develop` after approval
5. Include in next release cycle

### Release Management
- Semantic versioning (MAJOR.MINOR.PATCH)
- Tagged releases with detailed release notes
- Comprehensive testing before production deployment

## 🧪 Testing

### Test Suite
- **Unit Tests**: Component and utility function testing
- **Integration Tests**: End-to-end workflow validation
- **Manual Testing**: UI/UX and cross-browser testing

### Running Tests
```bash
# Run all tests
npm run test

# Run tests with coverage
npm run test:coverage

# Run tests in watch mode
npm run test:watch
```

### Test Coverage
- **Current Coverage**: 85%
- **Target Coverage**: 80% minimum
- **Critical Components**: 95% coverage required

## 📱 Usage Guide

### Adding Your First Activity
1. Click "Add Activity" in the navigation
2. Select an activity category (e.g., Transportation)
3. Choose specific activity type (e.g., Car - Petrol)
4. Enter the amount (e.g., 25 km)
5. Add a description (e.g., "Daily commute")
6. Click "Add Activity" to save

### Setting Carbon Goals
1. Navigate to the "Goals" section
2. Click "Add Goal"
3. Select goal type (daily, weekly, monthly, yearly)
4. Set your target CO₂ limit (e.g., 500 kg/month)
5. Add a description
6. Track your progress on the dashboard

### Viewing Your Impact
The dashboard provides:
- Total carbon emissions
- Current month progress
- Goal achievement status
- Emissions breakdown by category
- Recent activity history

## 🌍 Emission Factors

Our calculations use scientifically-backed emission factors:

### Transportation (kg CO₂/km)
- Car (Petrol): 0.21
- Car (Diesel): 0.17
- Car (Electric): 0.05
- Bus: 0.08
- Train: 0.04
- Flight (Domestic): 0.25
- Flight (International): 0.30

### Energy (kg CO₂/unit)
- Electricity: 0.5 per kWh
- Natural Gas: 2.0 per m³
- Heating Oil: 2.7 per L

### Food (kg CO₂/kg)
- Beef: 27.0
- Pork: 12.1
- Chicken: 6.9
- Fish: 6.1
- Vegetables: 2.0
- Dairy: 3.2

## 🤝 Contributing

We welcome contributions to EcoTrack! Please follow our development workflow:

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Make your changes** with appropriate tests
4. **Commit your changes**
   ```bash
   git commit -m 'feat: add amazing feature'
   ```
5. **Push to your branch**
   ```bash
   git push origin feature/amazing-feature
   ```
6. **Open a Pull Request**

### Code Standards
- Follow TypeScript and React best practices
- Write tests for new functionality
- Use conventional commit messages
- Ensure code passes linting and formatting

## 📋 Project Structure

```
ecotrack-carbon-tracker/
├── src/
│   ├── components/          # React components
│   │   ├── Dashboard.tsx
│   │   ├── ActivityForm.tsx
│   │   └── GoalsPanel.tsx
│   ├── types.ts            # TypeScript definitions
│   ├── App.tsx             # Main application
│   └── main.tsx           # Application entry point
├── docs/                   # Documentation
│   ├── CONFIGURATION_MANAGEMENT_REPORT.md
│   ├── CHANGE_LOG.md
│   └── TESTING_PROCEDURES.md
├── public/                 # Static assets
├── tests/                  # Test files
└── README.md              # This file
```

## 🔄 Changelog

### Version 1.2.0 (Current)
- ✅ Goal management system
- ✅ Enhanced activity tracking
- ✅ Improved dashboard analytics
- ✅ Better mobile responsiveness
- ✅ Enhanced data persistence

### Version 1.1.0
- ✅ Dashboard with visualizations
- ✅ Activity categorization
- ✅ Performance improvements

### Version 1.0.0
- ✅ Basic carbon footprint tracking
- ✅ Activity logging
- ✅ Local data storage

## 🎯 Roadmap

### Version 1.3.0 (Planned)
- 📊 Data export/import functionality
- 📈 Advanced analytics and trends
- 🏆 Achievement system
- 🌐 PWA capabilities

### Version 1.4.0 (Planned)
- 🔗 API integrations
- 🌤️ Weather-based adjustments
- 📱 Mobile app
- ☁️ Cloud synchronization

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Team

- **Project Manager**: [Name]
- **Technical Lead**: [Name]
- **Frontend Developers**: [Names]
- **QA Engineer**: [Name]

## 📞 Support

For support and questions:
- 📧 Email: support@ecotrack.app
- 🐛 Bug Reports: [GitHub Issues](https://github.com/team/ecotrack-carbon-tracker/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/team/ecotrack-carbon-tracker/discussions)

## 🌟 Acknowledgments

- Emission factors sourced from EPA and IPCC guidelines
- Icons provided by Lucide React
- UI components built with Tailwind CSS
- Testing framework by Jest and React Testing Library

---

**Built with ❤️ for a sustainable future**

*EcoTrack v1.2.0 - Helping individuals reduce their environmental impact through awareness and action.*